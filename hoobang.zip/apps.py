from django.apps import AppConfig


class HoobangConfig(AppConfig):
    name = 'hoobang'
